// CS1300 Spring 2020
// Author: Emmeline Nettles
// Recitation: 301 - Tetsumichi Umada
// Homework 6 - Problem 1
//item list
#include <iostream>
#include <fstream>
#include <string>
#include <vector>
using namespace std;
//don't return anything
void split(vector<string> toSplit, int countNum)
{
    char inputSeparator =',';
    string tester, tester2 = "";
    int priceMatch, startLine = 0;
    double cost = 0;
    double prices[countNum];
    //convert string prices to double prices
    for(int i = 0; i < countNum; i++){
        tester = toSplit[i];
        for(int x = 0; x < tester.length(); x++){
            if(tester[x]==inputSeparator){
                tester2 = tester.substr(x+1, tester.length());
                cost = stod(tester2);
            }
        }
        prices[i] = cost;
    }
    string maxProduct = "";
    string minProduct = "";
    double maxCost = cost;
    double minCost = cost;
    //find max and min prices
    for(int y = 0; y < countNum; y++){
        if(prices[y]>maxCost){
            maxCost = prices[y];
        }
        else if(prices[y]<minCost){
            minCost = prices[y];
        }
    }
    int runThrough = 0;
    string prdt = "";
    for(int z = 0; z < countNum; z++){
        prdt = toSplit[z];
        //find most expensive product
        if(maxCost == prices[z]){
            for(int a = 0; a < prdt.length(); a++){
                if(prdt[a]==inputSeparator){
                    maxProduct = prdt.substr(runThrough,a);
                }
            }
        }
        //find cheapest product
        else if(minCost == prices[z]){
            for(int a = 0; a < prdt.length(); a++){
                if(prdt[a]==inputSeparator){
                    minProduct = prdt.substr(runThrough,a);
                }
            }
        }
    }
    //print number of lines and the range of products
    cout << "The number of lines: " << countNum << endl;
    cout << "The most expensive product: " << maxProduct << endl;
    cout << "The least expensive product: " << minProduct << endl;
}
int main()
{
    //compute number of lines on the file, most exspensive product, least expensive product
    int count, newLine = 0;
    string inputfile;
    cout << "Enter the file name:" << endl;
    cin >> inputfile;
    ifstream itemList;
    itemList.open(inputfile);
    //if the file cannot be opened, output error message
    if(itemList.fail()){
        //fail
        cout << "Could not open file." << endl;
    }  
    //add all text to a vector
    else{
        vector<string> strWhole;
        string str = "";
        while (getline(itemList, str)) {
            if (str == ""){
                count--;
            }
            else{
                strWhole.push_back(str);
            }
            count++;
        }
        itemList.close();
        //send vector to split function
        split(strWhole, count);
    }
}