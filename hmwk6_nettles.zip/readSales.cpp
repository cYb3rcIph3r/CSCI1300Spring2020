// CS1300 Spring 2020
// Author: Emmeline Nettles
// Recitation: 301 - Tetsumichi Umada
// Homework 6 - Problem 2
#include <iostream>
#include <fstream>
#include <string>
//file to read multiple inputs and print out according to employee size and number of sales
int readSales(string file, string arr[], int arr2[][12], int arrSize){
    int finalNum, employees = 0;
    employees = arrSize;
    ifstream in_file;
    in_file.open(file);
    //If the file cannot be opened return -1
    if(in_file.fail()){
        finalNum = -1;
        return finalNum;
    }
    //If the array is full, print out the number of rows
    else if(arr2[employees][12] > 0){
        return arrSize;
    }
    //If the file can be opened and the array is not full, print out the number of employees
    else if(!in_file.fail()){
        return employees;
    }
}