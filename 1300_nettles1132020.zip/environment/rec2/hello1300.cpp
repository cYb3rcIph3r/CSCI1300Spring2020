//LAST UPDATED JANUARY 13, 2020 AT 5:27 PM
//Encountered issue with accidental deletion of 'rec2', recreated
//Misnamed second interation of 'test_Files.zip' as 'text_Files.zip'
//PROGRAM CODE TAKEN FROM INSTRUCTIONS FOLLOWED IN STEP 2.4-2.6 OF STEP 3 OF HOMEWORK 0
#include <iostream>
using namespace std;
int main()
{
	cout << "Hello World! Hello CSCi 1300" << endl;
}