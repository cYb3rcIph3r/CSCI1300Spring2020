//LAST UPDATED JANUARY 13, 2020 AT 4:25 PM
//PROGRAM CODE TAKEN FROM INSTRUCTIONS FOLLOWED IN STEP 2.4 OF HOMEWORK 0
#include <iostream>
using namespace std;
int main()
{
	cout << "Hello World! Hello CSCi 1300" << endl;
}